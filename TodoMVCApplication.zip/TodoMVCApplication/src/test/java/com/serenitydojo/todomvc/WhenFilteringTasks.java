package com.serenitydojo.todomvc;

import net.serenitybdd.junit.runners.SerenityParameterizedRunner;
import org.junit.runner.RunWith;


@RunWith(SerenityParameterizedRunner.class)
public class WhenFilteringTasks {
}
