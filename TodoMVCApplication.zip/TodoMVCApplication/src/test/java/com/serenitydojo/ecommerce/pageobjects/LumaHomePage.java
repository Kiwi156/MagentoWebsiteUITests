package com.serenitydojo.ecommerce.pageobjects;

import net.serenitybdd.annotations.DefaultUrl;
import net.thucydides.core.pages.PageObject;

@DefaultUrl("https://magento.softwaretestingboard.com/")
public class LumaHomePage extends PageObject {
}
