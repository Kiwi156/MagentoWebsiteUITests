package com.serenitydojo.todomvc;

public @interface TestData {
}
