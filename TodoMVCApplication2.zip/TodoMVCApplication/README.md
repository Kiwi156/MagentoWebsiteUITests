# Serenity JUnit Starter project

